﻿using EmployeeManagement.Validation;
using System;
using Xunit;

namespace EmployeeManagement.Tests.Validation
{
    public class AccountNumberValidationTests
    {
        //MethodWeTest_StateUnderTest_ExpectedBehavior

        private readonly AccountNumberValidation _validation;
        public AccountNumberValidationTests()
        {
            _validation = new AccountNumberValidation();
        }

        [Fact]
        public void IsValid_ValidAccountNumber_ReturnsTrue()
        {
            Assert.True(_validation.IsValid("123-1212121212-12"));
        }

        [Theory]
        [InlineData("12-1212121212-12")]
        [InlineData("1234-1212121212-12")]
        public void IsValid_AccountNumberFirstPartLengthWrong_ReturnsFalse(string accountNumber)
        {
            Assert.False(_validation.IsValid(accountNumber));
        }

        [Theory]
        [InlineData("123-12121212121-12")]
        [InlineData("123-121212121-12")]
        public void IsValid_AccountNumberMiddlePartLengthWrong_ReturnsFalse(string accountNumber)
        {
            Assert.False(_validation.IsValid(accountNumber));
        }

        [Theory]
        [InlineData("123-1212121212-1")]
        [InlineData("123-1212121212-121")]
        public void IsValid_AccountNumberLastPartLengthWrong_ReturnsFalse(string accountNumber)
        {
            Assert.False(_validation.IsValid(accountNumber));
        }

        [Theory]
        [InlineData("1231212121212-12")]
        [InlineData("123-121212121212")]
        [InlineData("123121212121212")]
        [InlineData("123_1212121212-12")]
        [InlineData("123-1212121212_12")]
        [InlineData("123_1212121212_12")]
        public void IsValid_InvalidDelimeters_ThrowsArgumentException(string accountNumber)
        {
            Assert.Throws<ArgumentException>(() => _validation.IsValid(accountNumber));
        }

        [Theory]
        [InlineData("a23-1212121212-12")]
        [InlineData("123-a212121212-12")]
        [InlineData("123-1212121212-a2")]
        public void IsValid_NonNumericCharacters_ReturnsFalse(string accountNumber)
        {
            Assert.False(_validation.IsValid(accountNumber));
        }
    }
}
