﻿using EmployeeManagement.Contracts;
using EmployeeManagement.Controllers;
using EmployeeManagement.Data.Entities;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace EmployeeManagement.Tests.Controllers
{
    public class EmployeesControllerTests
    {
        private readonly Mock<IEmployeeRepository> _mockRepo;
        private readonly EmployeesController _controller;

        public EmployeesControllerTests()
        {
            _mockRepo = new Mock<IEmployeeRepository>();
            _controller = new EmployeesController(_mockRepo.Object);
        }

        [Fact]
        public void Index_ActionExecutes_ReturnsViewResult()
        {
            var result = _controller.Index();
            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public void Index_ActionExecutes_ReturnsExactNumberOfEmployees()
        {
            _mockRepo.Setup(x => x.GetAll())
                .Returns(new List<Employee>
                {
                    new Employee(),
                    new Employee()
                });

            var result = _controller.Index();
            var viewResult = Assert.IsType<ViewResult>(result);
            var employees = Assert.IsType<List<Employee>>(viewResult.Model);
            Assert.Equal(2, employees.Count);
        }

        [Fact]
        public void Create_ActionExecutes_ReturnsViewResult()
        {
            var result = _controller.Create();
            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public void Create_InvalidModelState_ReturnsTheSameView()
        {
            _controller.ModelState.AddModelError("Name", "Name is required");

            var employee = new Employee
            {
                AccountNumber = "123-1212121212-12",
                BirthDate = new DateTime(1990, 5, 24)
            };

            var result = _controller.Create(employee);
            var viewResult = Assert.IsType<ViewResult>(result);
            var postedEmployee = Assert.IsType<Employee>(viewResult.Model);

            Assert.Equal(employee.AccountNumber, postedEmployee.AccountNumber);
            Assert.Equal(employee.BirthDate, postedEmployee.BirthDate);
        }

        [Fact]
        public void Create_InvalidModelState_RepositoryCreateMethodNeverExecutes()
        {
            _controller.ModelState.AddModelError("Name", "Name is required");

            var employee = new Employee
            {
                AccountNumber = "123-1212121212-12",
                BirthDate = new DateTime(1990, 5, 24)
            };

            _controller.Create(employee);

            _mockRepo.Verify(x => x.Create(It.IsAny<Employee>()), Times.Never);
        }

        //ModelState valid'de repo createin bir kex execute olduğunu verify edin (test methodu 1)
        [Fact]
        public void Create_ValidModelState_RepositoryCreateMethodExecutesOnce()
        {
            var employee = new Employee
            {
                Name = "Sarp Vahabi",
                AccountNumber = "123-1212121212-12",
                BirthDate = new DateTime(1990, 5, 24)
            };

            _controller.Create(employee);
            _mockRepo.Verify(x => x.Create(employee), Times.Once);
        }

        [Fact]
        public void Create_ValidModelState_RedirectsToIndexAction()
        {
            var employee = new Employee
            {
                Name = "Sarp Vahabi",
                AccountNumber = "123-1212121212-12",
                BirthDate = new DateTime(1990, 5, 24)
            };

            var redirectToActionResult = Assert.IsType<RedirectToActionResult>(_controller.Create(employee));
            Assert.Null(redirectToActionResult.ControllerName);
            Assert.Equal("Index", redirectToActionResult.ActionName);
        }

        [Fact]
        public void Create_ValidModelState_CreatedEmployeeShouldBeTheOriginalEmployee()
        {
            Employee createdEmployee = null;

            _mockRepo.Setup(x => x.Create(It.IsAny<Employee>()))
                .Callback<Employee>(x => createdEmployee = x);

            var employeeToBeCreated = new Employee
            {
                Name = "Sarp Vahabi",
                AccountNumber = "123-1212121212-12",
                BirthDate = new DateTime(1990, 5, 24)
            };

            _controller.Create(employeeToBeCreated);

            _mockRepo.Verify(x => x.Create(employeeToBeCreated), Times.Once);

            Assert.Equal(createdEmployee.Name, employeeToBeCreated.Name);
            Assert.Equal(createdEmployee.BirthDate, employeeToBeCreated.BirthDate);
            Assert.Equal(createdEmployee.AccountNumber, employeeToBeCreated.AccountNumber);
        }
    }
}
