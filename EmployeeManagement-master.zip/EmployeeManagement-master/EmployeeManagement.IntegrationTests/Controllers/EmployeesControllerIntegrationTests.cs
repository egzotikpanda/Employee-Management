﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace EmployeeManagement.IntegrationTests.Controllers
{
    public class EmployeesControllerIntegrationTests : IClassFixture<TestingWebAppFactory<Startup>>
    {
        private readonly HttpClient _client;
        public EmployeesControllerIntegrationTests(TestingWebAppFactory<Startup> factory)
        {
            _client = factory.CreateClient();
        }

        [Fact]
        public async Task Create_WhenCalled_ReturnsCreateForm()
        {
            var response = await _client.GetAsync("/Employees/Create");

            response.EnsureSuccessStatusCode();

            var responseString = await response.Content.ReadAsStringAsync();

            Assert.Contains("Please provide a new employee data", responseString);
        }

        [Fact]
        public async Task Index_WhenCalled_ReturnsIndexPage()
        {
            var response = await _client.GetAsync("/Employees");

            response.EnsureSuccessStatusCode();

            var responseString = await response.Content.ReadAsStringAsync();

            Assert.Contains("Index", responseString);
        }

        [Fact]
        public async Task Create_InvalidModel_ReturnsSameViewWithErrorMessages()
        {
            var postRequest = new HttpRequestMessage(HttpMethod.Post, "/Employees/Create");

            var formModel = new Dictionary<string, string>
            {
                {"Name","Beliz Nalıncıoğlu" },
                {"BirthDate", DateTime.Now.AddYears(-26).ToShortDateString() }
            };

            postRequest.Content = new FormUrlEncodedContent(formModel);

            var response = await _client.SendAsync(postRequest);

            response.EnsureSuccessStatusCode();

            var responseString = await response.Content.ReadAsStringAsync();

            Assert.Contains(">Account number is required</span>", responseString);
        }

        [Fact]
        public async Task Create_WhenPostExecuted_ReturnsToIndexWithCreatedEmployee()
        {
            var postRequest = new HttpRequestMessage(HttpMethod.Post, "/Employees/Create");

            var formModel = new Dictionary<string, string>
            {
                {"Name","Beliz Nalıncıoğlu" },
                {"AccountNumber","111-1212121212-12" },
                {"BirthDate", DateTime.Now.AddYears(-26).ToShortDateString() }
            };

            postRequest.Content = new FormUrlEncodedContent(formModel);

            var response = await _client.SendAsync(postRequest);

            response.EnsureSuccessStatusCode();

            var responseString = await response.Content.ReadAsStringAsync();

            Assert.Contains("Index", responseString);
            Assert.Contains("Beliz", responseString);
            Assert.Contains("111-1212121212-12", responseString);
        }
    }
}
