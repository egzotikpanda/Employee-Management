﻿using EmployeeManagement.Contracts;
using EmployeeManagement.Data.Entities;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeManagement.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeesController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        public IActionResult Index()
        {
            var employees = _employeeRepository.GetAll();
            return View(employees);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create([Bind("Name, AccountNumber, BirthDate")] Employee employee)
        {
            if (!ModelState.IsValid)
                return View(employee);

            _employeeRepository.Create(employee);
            return RedirectToAction(nameof(Index));
        }
    }
}
