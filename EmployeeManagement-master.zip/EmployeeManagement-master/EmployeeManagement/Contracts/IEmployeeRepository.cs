﻿using EmployeeManagement.Data.Entities;
using System;
using System.Collections.Generic;

namespace EmployeeManagement.Contracts
{
    public interface IEmployeeRepository
    {
        IEnumerable<Employee> GetAll();
        Employee Get(Guid id);
        void Create(Employee employee);
    }
}
