﻿using System;
using System.Linq;

namespace EmployeeManagement.Validation
{
    public class AccountNumberValidation
    {
        private const int StartingPartLength = 3;
        private const int MiddlePartLength = 10;
        private const int LastPartLength = 2;

        public bool IsValid(string accountNumber)
        {
            var delimetersCount = accountNumber.Count(x => x == '-');

            if (delimetersCount != 2)
                throw new ArgumentException();

            var firstDelimeter = accountNumber.IndexOf("-");
            var secondDelimeter = accountNumber.LastIndexOf("-");

            if (firstDelimeter != StartingPartLength 
                || secondDelimeter != StartingPartLength + MiddlePartLength + 1 
                || accountNumber.Length - StartingPartLength - MiddlePartLength - delimetersCount != LastPartLength)
                return false;

            foreach (var c in accountNumber)
                if (!char.IsDigit(c) && c != '-')
                    return false;

            return true;
        }
    }
}
