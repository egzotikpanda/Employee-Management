﻿using EmployeeManagement.Contracts;
using EmployeeManagement.Data;
using EmployeeManagement.Data.Entities;
using EmployeeManagement.Validation;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeManagement.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly EmployeesDbContext _context;
        private readonly AccountNumberValidation _validation;

        public EmployeeRepository(EmployeesDbContext context)
        {
            _context = context;
            _validation = new AccountNumberValidation();
        }

        public void Create(Employee employee)
        {
            if (!_validation.IsValid(employee.AccountNumber))
                throw new ArgumentException("AccountNumber");

            _context.Employees.Add(employee);
            _context.SaveChanges();
        }

        public Employee Get(Guid id)
        {
            return _context.Employees.FirstOrDefault(x => x.Id == id);
        }

        public IEnumerable<Employee> GetAll()
        {
            return _context.Employees.ToArray();
        }
    }
}
